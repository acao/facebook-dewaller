# 0.0.3
First public release!
- hides log-in overlay
- hides giant footer CTA that also appears

# 0.0.4
Not kitten around
- Introduces proper firefox for android support (and other browser support soon!)
  - hides header CTA
  - hides captive CTA (hopefully?)
- hides another CTA on people profiles on desktop